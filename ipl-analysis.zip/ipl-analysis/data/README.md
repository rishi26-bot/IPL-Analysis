# Data

Download the **IPL Complete Dataset (2008-2024)** from Kaggle:
https://www.kaggle.com/datasets/patrickb1912/ipl-complete-dataset-20082020

Place these two files in this folder:

```
data/
├── matches.csv
└── deliveries.csv
```

The CSVs are git-ignored to keep the repository small.
