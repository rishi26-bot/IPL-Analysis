"""
IPL Data Analysis: player performance, toss impact and venue trends.

Usage:
    python src/analysis.py --data-dir data --img-dir images --out-dir outputs

Expects matches.csv and deliveries.csv (Kaggle "IPL Complete Dataset").
Generates charts in images/, summary tables in outputs/ and a
key_findings.md file with auto-generated insights.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from scipy.stats import binomtest

sns.set_theme(style="whitegrid", context="notebook")

# ----------------------------------------------------------------------------
# Cleaning helpers
# ----------------------------------------------------------------------------
TEAM_RENAMES = {
    "Delhi Daredevils": "Delhi Capitals",
    "Kings XI Punjab": "Punjab Kings",
    "Royal Challengers Bengaluru": "Royal Challengers Bangalore",
    "Rising Pune Supergiant": "Rising Pune Supergiants",
}

VENUE_FIXES = {
    "M.Chinnaswamy Stadium": "M Chinnaswamy Stadium",
    "Feroz Shah Kotla": "Arun Jaitley Stadium",
    "Punjab Cricket Association Stadium": "Punjab Cricket Association IS Bindra Stadium",
    "Sardar Patel Stadium": "Narendra Modi Stadium",
    "Subrata Roy Sahara Stadium": "Maharashtra Cricket Association Stadium",
    "Sheikh Zayed Stadium": "Zayed Cricket Stadium",
}

# Seasons the dataset labels with two years (e.g. "2007/08")
SEASON_FIXES = {"2007/08": 2008, "2009/10": 2010, "2020/21": 2020}

# Dismissals that are not credited to the bowler
NON_BOWLER_WICKETS = ["run out", "retired hurt", "retired out", "obstructing the field"]


def parse_season(value) -> int:
    s = str(value)
    return SEASON_FIXES.get(s, int(s[:4]))


def clean_venue(name: str) -> str:
    if pd.isna(name):
        return name
    base = str(name).split(",")[0].strip()
    return VENUE_FIXES.get(base, base)


def load_data(data_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    matches = pd.read_csv(data_dir / "matches.csv")
    deliveries = pd.read_csv(data_dir / "deliveries.csv")

    # Older versions of the dataset use "batsman" instead of "batter"
    if "batter" not in deliveries.columns and "batsman" in deliveries.columns:
        deliveries = deliveries.rename(columns={"batsman": "batter"})

    for col in ["team1", "team2", "toss_winner", "winner"]:
        matches[col] = matches[col].replace(TEAM_RENAMES)
    for col in ["batting_team", "bowling_team"]:
        deliveries[col] = deliveries[col].replace(TEAM_RENAMES)

    matches["venue"] = matches["venue"].apply(clean_venue)
    matches["season"] = matches["season"].apply(parse_season)

    deliveries["extras_type"] = deliveries["extras_type"].fillna("")
    # Drop super overs (inning 3+)
    deliveries = deliveries[deliveries["inning"] <= 2].copy()
    # Some versions index overs from 0; normalise to 1-20
    if deliveries["over"].min() == 0:
        deliveries["over"] = deliveries["over"] + 1

    return matches, deliveries


def decided_matches(matches: pd.DataFrame) -> pd.DataFrame:
    """Matches with a winner (drops no-results / abandoned games)."""
    m = matches[matches["winner"].notna()].copy()
    m["toss_win_match_win"] = m["toss_winner"] == m["winner"]
    return m


def save(fig, name: str, img_dir: Path) -> None:
    fig.tight_layout()
    fig.savefig(img_dir / name, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------
# 1. Overview
# ----------------------------------------------------------------------------
def overview(matches, img_dir, findings):
    per_season = matches.groupby("season")["id"].count()
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.barplot(x=per_season.index, y=per_season.values, color="#1f77b4", ax=ax)
    ax.set(title="Matches Played per IPL Season", xlabel="Season", ylabel="Matches")
    ax.tick_params(axis="x", rotation=45)
    save(fig, "01_matches_per_season.png", img_dir)
    findings.append(
        f"- Dataset covers **{len(matches)} matches** across "
        f"**{matches['season'].nunique()} seasons** "
        f"({matches['season'].min()}-{matches['season'].max()})."
    )


# ----------------------------------------------------------------------------
# 2. Toss impact
# ----------------------------------------------------------------------------
def toss_analysis(m, img_dir, out_dir, findings):
    n = len(m)
    k = int(m["toss_win_match_win"].sum())
    pct = k / n * 100
    p_value = binomtest(k, n, 0.5).pvalue
    verdict = (
        "a statistically significant edge"
        if p_value < 0.05
        else "no statistically significant edge"
    )
    findings.append(
        f"- Toss winners won **{pct:.1f}%** of {n} decided matches "
        f"(binomial test vs 50%: p = {p_value:.3f}), i.e. {verdict}."
    )

    by_decision = m.groupby("toss_decision").agg(
        win_pct=("toss_win_match_win", "mean"), matches=("id", "count")
    )
    by_decision["win_pct"] = (by_decision["win_pct"] * 100).round(1)
    by_decision.to_csv(out_dir / "toss_by_decision.csv")
    best = by_decision["win_pct"].idxmax()
    findings.append(
        f"- Toss winners who chose to **{best}** first won "
        f"{by_decision.loc[best, 'win_pct']:.1f}% of their matches "
        f"(the other choice: {by_decision['win_pct'].drop(best).iloc[0]:.1f}%)."
    )

    by_season = m.groupby("season").agg(
        toss_win_pct=("toss_win_match_win", lambda s: s.mean() * 100),
        field_first_pct=("toss_decision", lambda s: (s == "field").mean() * 100),
        matches=("id", "count"),
    ).round(1)
    by_season.to_csv(out_dir / "toss_by_season.csv")

    fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
    axes[0].plot(by_season.index, by_season["toss_win_pct"], marker="o")
    axes[0].axhline(50, color="red", ls="--", label="50% (no advantage)")
    axes[0].set(title="Toss Winner's Win % by Season", xlabel="Season", ylabel="Win %")
    axes[0].legend()

    axes[1].plot(by_season.index, by_season["field_first_pct"], marker="o", color="green")
    axes[1].set(title="% of Toss Winners Choosing to Field", xlabel="Season", ylabel="%")

    sns.barplot(x=by_decision.index, y=by_decision["win_pct"], ax=axes[2],
                palette="Set2", hue=by_decision.index, legend=False)
    axes[2].axhline(50, color="red", ls="--")
    axes[2].set(title="Win % by Toss Decision", xlabel="Decision", ylabel="Win %")
    save(fig, "02_toss_impact.png", img_dir)


# ----------------------------------------------------------------------------
# 3. Venue trends
# ----------------------------------------------------------------------------
def venue_analysis(m, d, img_dir, out_dir, findings, min_matches=20):
    first_score = (
        d[d["inning"] == 1].groupby("match_id")["total_runs"].sum().rename("first_innings_score")
    )
    chasing_team = (
        d[d["inning"] == 2].groupby("match_id")["batting_team"].first().rename("chasing_team")
    )
    mv = (
        m.merge(first_score, left_on="id", right_index=True, how="inner")
        .merge(chasing_team, left_on="id", right_index=True, how="inner")
    )
    mv["chase_win"] = mv["winner"] == mv["chasing_team"]

    stats = mv.groupby("venue").agg(
        matches=("id", "count"),
        avg_first_innings=("first_innings_score", "mean"),
        chase_win_pct=("chase_win", lambda s: s.mean() * 100),
    ).round(1)
    stats.to_csv(out_dir / "venue_stats.csv")

    vs = stats[stats["matches"] >= min_matches]
    if len(vs) < 5:  # small datasets: fall back to the busiest venues
        vs = stats.nlargest(8, "matches")

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    a = vs.sort_values("avg_first_innings")
    axes[0].barh(a.index, a["avg_first_innings"], color="#ff7f0e")
    axes[0].set(title="Average 1st Innings Score by Venue", xlabel="Runs")
    b = vs.sort_values("chase_win_pct")
    axes[1].barh(b.index, b["chase_win_pct"], color="#2ca02c")
    axes[1].axvline(50, color="red", ls="--")
    axes[1].set(title="Chasing Team Win % by Venue", xlabel="Win %")
    save(fig, "03_venue_trends.png", img_dir)

    high, low = a.index[-1], a.index[0]
    best_chase = b.index[-1]
    overall_chase = mv["chase_win"].mean() * 100
    findings.append(
        f"- Highest-scoring venue (min {min_matches} matches where possible): **{high}** "
        f"({a['avg_first_innings'].iloc[-1]:.0f} avg 1st-innings runs); "
        f"lowest: **{low}** ({a['avg_first_innings'].iloc[0]:.0f})."
    )
    findings.append(
        f"- Chasing teams won **{overall_chase:.1f}%** of matches overall; "
        f"the most chase-friendly venue is **{best_chase}** "
        f"({b['chase_win_pct'].iloc[-1]:.0f}%)."
    )


# ----------------------------------------------------------------------------
# 4. Player performance
# ----------------------------------------------------------------------------
def batting_analysis(d, img_dir, out_dir, findings, min_balls=500):
    legal_for_batter = d[d["extras_type"] != "wides"]
    runs = d.groupby("batter")["batsman_runs"].sum()
    balls = legal_for_batter.groupby("batter").size()
    outs = d["player_dismissed"].value_counts()
    fours = d[d["batsman_runs"] == 4].groupby("batter").size()
    sixes = d[d["batsman_runs"] == 6].groupby("batter").size()

    bat = pd.DataFrame({"runs": runs, "balls": balls}).fillna(0)
    bat["dismissals"] = outs.reindex(bat.index).fillna(0)
    bat["fours"] = fours.reindex(bat.index).fillna(0).astype(int)
    bat["sixes"] = sixes.reindex(bat.index).fillna(0).astype(int)
    bat["strike_rate"] = (bat["runs"] / bat["balls"] * 100).round(1)
    bat["average"] = (bat["runs"] / bat["dismissals"].replace(0, pd.NA)).astype(float).round(1)
    bat = bat[bat["balls"] >= min_balls].sort_values("runs", ascending=False)
    bat.to_csv(out_dir / "batting_leaderboard.csv")

    top = bat.head(10)
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    axes[0].barh(top.index[::-1], top["runs"][::-1], color="#1f77b4")
    axes[0].set(title="Top 10 IPL Run Scorers", xlabel="Runs")

    sns.scatterplot(data=bat, x="average", y="strike_rate", size="runs", sizes=(30, 400),
                    alpha=0.6, legend=False, ax=axes[1])
    for name, row in top.iterrows():
        axes[1].annotate(name, (row["average"], row["strike_rate"]), fontsize=8,
                         xytext=(4, 4), textcoords="offset points")
    axes[1].set(title=f"Batting Average vs Strike Rate (min {min_balls} balls)",
                xlabel="Average", ylabel="Strike Rate")
    save(fig, "04_batting.png", img_dir)

    findings.append(
        f"- Leading run scorer: **{top.index[0]}** ({int(top['runs'].iloc[0])} runs, "
        f"SR {top['strike_rate'].iloc[0]})."
    )
    sr = bat[bat["runs"] >= 1000].sort_values("strike_rate", ascending=False)
    if len(sr):
        findings.append(
            f"- Highest strike rate among batters with 1000+ runs: **{sr.index[0]}** "
            f"({sr['strike_rate'].iloc[0]})."
        )


def bowling_analysis(d, img_dir, out_dir, findings, min_balls=300):
    legal = d[~d["extras_type"].isin(["wides", "noballs"])]
    conceded = d["total_runs"].where(~d["extras_type"].isin(["byes", "legbyes"]), 0)
    wk = d[(d["is_wicket"] == 1) & (~d["dismissal_kind"].isin(NON_BOWLER_WICKETS))]

    bowl = pd.DataFrame({
        "wickets": wk.groupby("bowler").size(),
        "legal_balls": legal.groupby("bowler").size(),
        "runs_conceded": conceded.groupby(d["bowler"]).sum(),
    }).fillna(0)
    bowl["economy"] = (bowl["runs_conceded"] / (bowl["legal_balls"] / 6)).round(2)
    bowl["strike_rate"] = (bowl["legal_balls"] / bowl["wickets"].replace(0, pd.NA)).astype(float).round(1)
    bowl = bowl[bowl["legal_balls"] >= min_balls].sort_values("wickets", ascending=False)
    bowl.to_csv(out_dir / "bowling_leaderboard.csv")

    top = bowl.head(10)
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    axes[0].barh(top.index[::-1], top["wickets"][::-1], color="#d62728")
    axes[0].set(title="Top 10 IPL Wicket Takers", xlabel="Wickets")

    sns.scatterplot(data=bowl, x="economy", y="wickets", alpha=0.6, ax=axes[1])
    for name, row in top.iterrows():
        axes[1].annotate(name, (row["economy"], row["wickets"]), fontsize=8,
                         xytext=(4, 4), textcoords="offset points")
    axes[1].set(title=f"Economy vs Wickets (min {min_balls} balls)",
                xlabel="Economy Rate", ylabel="Wickets")
    save(fig, "05_bowling.png", img_dir)

    findings.append(
        f"- Leading wicket taker: **{top.index[0]}** ({int(top['wickets'].iloc[0])} wickets, "
        f"economy {top['economy'].iloc[0]})."
    )
    elite = bowl[bowl["legal_balls"] >= 1000].sort_values("economy")
    if len(elite):
        findings.append(
            f"- Most economical bowler (1000+ legal balls): **{elite.index[0]}** "
            f"({elite['economy'].iloc[0]} runs/over)."
        )


def phase_analysis(d, img_dir, out_dir, findings):
    rr = d.groupby("over")["total_runs"].mean().mul(6).round(2)
    rr.to_csv(out_dir / "run_rate_by_over.csv", header=["run_rate"])
    colors = ["#1f77b4" if o <= 6 else "#ff7f0e" if o <= 15 else "#d62728" for o in rr.index]
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.bar(rr.index, rr.values, color=colors)
    ax.set(title="Average Run Rate by Over (blue: powerplay, orange: middle, red: death)",
           xlabel="Over", ylabel="Runs per over")
    ax.set_xticks(rr.index)
    save(fig, "06_run_rate_by_over.png", img_dir)

    pp = rr[rr.index <= 6].mean()
    mid = rr[(rr.index > 6) & (rr.index <= 15)].mean()
    death = rr[rr.index > 15].mean()
    findings.append(
        f"- Average run rate: powerplay **{pp:.2f}**, middle overs **{mid:.2f}**, "
        f"death overs **{death:.2f}** runs/over."
    )


def potm_analysis(matches, img_dir, out_dir, findings):
    potm = matches["player_of_match"].value_counts().head(10)
    potm.to_csv(out_dir / "player_of_match_top10.csv", header=["awards"])
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(potm.index[::-1], potm.values[::-1], color="#9467bd")
    ax.set(title="Most Player-of-the-Match Awards", xlabel="Awards")
    save(fig, "07_player_of_match.png", img_dir)
    findings.append(f"- Most Player-of-the-Match awards: **{potm.index[0]}** ({potm.iloc[0]}).")


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="IPL data analysis")
    parser.add_argument("--data-dir", default="data", type=Path)
    parser.add_argument("--img-dir", default="images", type=Path)
    parser.add_argument("--out-dir", default="outputs", type=Path)
    args = parser.parse_args()
    args.img_dir.mkdir(parents=True, exist_ok=True)
    args.out_dir.mkdir(parents=True, exist_ok=True)

    matches, deliveries = load_data(args.data_dir)
    decided = decided_matches(matches)
    findings: list[str] = []

    print("Running analysis...")
    overview(matches, args.img_dir, findings)
    toss_analysis(decided, args.img_dir, args.out_dir, findings)
    venue_analysis(decided, deliveries, args.img_dir, args.out_dir, findings)
    batting_analysis(deliveries, args.img_dir, args.out_dir, findings)
    bowling_analysis(deliveries, args.img_dir, args.out_dir, findings)
    phase_analysis(deliveries, args.img_dir, args.out_dir, findings)
    potm_analysis(matches, args.img_dir, args.out_dir, findings)

    report = "# Key Findings\n\n" + "\n".join(findings) + "\n"
    (args.out_dir / "key_findings.md").write_text(report, encoding="utf-8")
    print(report)
    print(f"Charts saved to {args.img_dir}/, tables to {args.out_dir}/")


if __name__ == "__main__":
    main()
